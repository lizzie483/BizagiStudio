/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadenaderesponsabilidad;

/**
 *
 * @author Lizeth
 */
public class Matricula {
     String proceso;
     String asesor;
     
      public Matricula(String p, String a){
          this.proceso=p;
          this.asesor=a;
     }
     
     public String proceso(){
          return this.proceso;
     }
     
     public String asesor(){
          return this.asesor;
     }
    
     
}
