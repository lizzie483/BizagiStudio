/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadenaderesponsabilidad;

/**
 *
 * @author Lizeth
 */
public class Handler3 extends AbstractHandler{
     public Matricula evaluarMatricula(float creditos){
          Matricula m = new Matricula("Asesoria Super-Creditos","Juana Segura");
          return m;
         
     }
}
